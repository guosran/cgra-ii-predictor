#!/usr/bin/env python3
"""Generate an Amoeba task/shape cost catalogue from a mapper surrogate.

The adapter consumes a frozen candidate JSONL manifest, one pre-mapper Neura
DFG per task, analytical RecMII/ResMII facts, and frontend-provided startup
cycles.  It predicts only unique ``(task DFG, mapper rows, mapper cols)``
queries.  Program-level scoring and top-k selection remain Amoeba's job.
"""

from __future__ import annotations

import argparse
from functools import lru_cache
import hashlib
import json
import math
from pathlib import Path
import sys
import time
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = PROJECT_ROOT / "src"
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))
if str(Path(__file__).resolve().parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parent))

import torch  # noqa: E402

from amoeba_protocol import (  # noqa: E402
    CANDIDATE_SCHEMA,
    COST_SCHEMA,
    SEARCH_SCOPE,
    SHAPE_POLICY,
    SOURCE_TASK_BODY_SHA_ATTR,
    SPATIAL_CAPACITY_POLICY,
)
from cgra_ii_predictor.dfg import (  # noqa: E402
    require_neura_route_expanded_dfg,
)
from cgra_ii_predictor.mapper_model import (  # noqa: E402
    CategoricalMapperIIModel,
    DirectMapperIIEnsemble,
    DirectMapperIIModel,
    RidgeMapperIIModel,
    MAPPER_FEATURE_NAMES,
    MapperModelConfig,
    mapper_feature_names,
    mapper_feature_vector,
)
from cgra_ii_predictor.shape_protocol import (  # noqa: E402
    SHAPE_PROTOCOL,
    SHAPE_PROTOCOL_ID,
    get_shape_protocol,
    get_shape_protocol_for_per_cgra,
)


ANALYTICAL_INPUT_SCHEMA = "cgra-ii-amoeba-query-features"
ADAPTER_FEATURE_SCHEMA = "cgra-ii-amoeba-direct-mapper-features"
CHECKPOINT_SCHEMA = "cgra-ii-direct-mapper-model"
CATEGORICAL_CHECKPOINT_SCHEMA = "cgra-ii-categorical-mapper-model"
RIDGE_CHECKPOINT_SCHEMA = "cgra-ii-ridge-mapper-model"
ENSEMBLE_CHECKPOINT_SCHEMA = "cgra-ii-direct-mapper-ensemble"
FINAL_MODEL_DIR = PROJECT_ROOT / "models" / "final"
DEFAULT_MODEL = FINAL_MODEL_DIR / "mapper.pt"

QueryKey = Tuple[str, int, int]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_json_sha256(value: object) -> str:
    encoded = json.dumps(
        value, sort_keys=True, separators=(",", ":"), allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _object(value: object, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{label} must be an object")
    return value


def _positive_integer(value: object, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{label} must be a positive integer")
    return value


def _positive_number(value: object, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be a positive finite number")
    result = float(value)
    if not math.isfinite(result) or result <= 0.0:
        raise ValueError(f"{label} must be a positive finite number")
    return result


def _nonnegative_number(value: object, label: str) -> float:
    """Read an analytical bound, for which zero is a valid value."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be a non-negative finite number")
    result = float(value)
    if not math.isfinite(result) or result < 0.0:
        raise ValueError(f"{label} must be a non-negative finite number")
    return result


def _sha256_string(value: object, label: str) -> str:
    if (
        not isinstance(value, str) or len(value) != 64 or
        any(character not in "0123456789abcdef" for character in value)
    ):
        raise ValueError(f"{label} must be a lowercase SHA-256")
    return value


def source_task_body_sha256(dfg_text: str, task: str) -> str:
    """Read the source Taskflow body identity embedded by the DFG exporter."""
    import re

    pattern = re.compile(
        rf'"?{re.escape(SOURCE_TASK_BODY_SHA_ATTR)}"?\s*=\s*"([^"]+)"'
    )
    values = pattern.findall(dfg_text)
    if len(values) != 1:
        raise ValueError(
            f"task DFG for {task} must contain exactly one "
            f"{SOURCE_TASK_BODY_SHA_ATTR} attribute"
        )
    return _sha256_string(values[0], f"source body hash for task {task}")


def _static_shape_alphabet(
    grid_rows: int, grid_cols: int, max_cgras_per_task: int,
) -> List[Tuple[int, int]]:
    """Mirror Amoeba's deterministic fixed-orientation rectangle order."""
    shapes = []
    for count in range(1, min(max_cgras_per_task, grid_rows * grid_cols) + 1):
        for rows in range(1, grid_rows + 1):
            if count % rows == 0 and count // rows <= grid_cols:
                shapes.append((rows, count // rows))
    return shapes


@lru_cache(maxsize=None)
def _pack_normalized_rectangles(
    rectangles: Tuple[Tuple[int, int], ...], grid_rows: int, grid_cols: int,
) -> bool:
    """Exactly place fixed-orientation rectangles using a physical-cell mask."""
    placements = []
    for rows, cols in rectangles:
        masks = []
        for origin_row in range(grid_rows - rows + 1):
            for origin_col in range(grid_cols - cols + 1):
                mask = 0
                for row in range(origin_row, origin_row + rows):
                    for col in range(origin_col, origin_col + cols):
                        mask |= 1 << (row * grid_cols + col)
                masks.append(mask)
        placements.append(tuple(masks))

    @lru_cache(maxsize=None)
    def place(rectangle_index: int, occupied: int) -> bool:
        if rectangle_index == len(placements):
            return True
        for mask in placements[rectangle_index]:
            if mask & occupied == 0 and place(
                rectangle_index + 1, occupied | mask,
            ):
                return True
        return False

    return place(0, 0)


def _can_pack_fixed_rectangles(
    rectangles: Sequence[Tuple[int, int]], grid_rows: int, grid_cols: int,
) -> bool:
    """Check simultaneous fit; no rectangle is rotated implicitly."""
    if sum(rows * cols for rows, cols in rectangles) > grid_rows * grid_cols:
        return False
    if any(
        rows <= 0 or cols <= 0 or rows > grid_rows or cols > grid_cols
        for rows, cols in rectangles
    ):
        return False
    # Packing feasibility ignores task identity. Normalizing improves cache reuse
    # without changing the direction of any rectangle.
    normalized = tuple(sorted(
        rectangles,
        key=lambda shape: (shape[0] * shape[1], max(shape), shape),
        reverse=True,
    ))
    return _pack_normalized_rectangles(normalized, grid_rows, grid_cols)


def _packable_shape_index_tuples(
    task_count: int, shape_alphabet: Sequence[Tuple[int, int]],
    grid_rows: int, grid_cols: int,
) -> Iterable[Tuple[int, ...]]:
    """Yield the exact packed subset in Amoeba's task-major shape order."""
    grid_area = grid_rows * grid_cols
    selected_indices: List[int] = []
    selected_shapes: List[Tuple[int, int]] = []

    def visit(task_index: int, selected_area: int) -> Iterable[Tuple[int, ...]]:
        if task_index == task_count:
            if _can_pack_fixed_rectangles(
                selected_shapes, grid_rows, grid_cols,
            ):
                yield tuple(selected_indices)
            return
        for shape_index, shape in enumerate(shape_alphabet):
            area = shape[0] * shape[1]
            if selected_area + area > grid_area:
                continue
            selected_indices.append(shape_index)
            selected_shapes.append(shape)
            yield from visit(task_index + 1, selected_area + area)
            selected_shapes.pop()
            selected_indices.pop()

    yield from visit(0, 0)


def load_candidate_manifest(path: Path) -> Dict[str, Any]:
    """Validate Amoeba's packing-pruned static space and derive its queries.

    Amoeba enumerates the full single-task shape alphabet, keeps only tuples
    whose fixed-orientation rectangles can coexist on the physical grid, and
    assigns contiguous IDs to those survivors.  This adapter validates that
    frozen feasible set; it does not use temporal reuse to admit an
    over-capacity tuple.  ``cost_queries`` is the exact set of task/shape
    pairs referenced by at least one retained candidate.
    """
    header: Optional[Mapping[str, Any]] = None
    footer: Optional[Mapping[str, Any]] = None
    candidates: List[Mapping[str, Any]] = []
    for line_number, line in enumerate(path.read_text().splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = _object(json.loads(line), f"line {line_number}")
        except json.JSONDecodeError as error:
            raise ValueError(
                f"invalid candidate JSONL at line {line_number}: {error}"
            ) from error
        if record.get("schema") != CANDIDATE_SCHEMA:
            raise ValueError("candidate manifest schema mismatch")
        kind = record.get("record_type")
        if kind == "header":
            if header is not None or candidates or footer is not None:
                raise ValueError("candidate manifest header is misplaced")
            header = record
        elif kind == "candidate":
            if header is None or footer is not None:
                raise ValueError("candidate record is outside header/footer")
            candidates.append(record)
        elif kind == "footer":
            if header is None or footer is not None:
                raise ValueError("candidate manifest footer is misplaced")
            footer = record
        else:
            raise ValueError(f"unknown candidate record_type: {kind!r}")
    if header is None or footer is None:
        raise ValueError("candidate manifest is incomplete")
    if not isinstance(header.get("function"), str) or not header["function"]:
        raise ValueError("candidate manifest function is missing")
    if header.get("search_scope") != SEARCH_SCOPE:
        raise ValueError("only static Amoeba candidate manifests are supported")
    if header.get("shape_policy") != SHAPE_POLICY:
        raise ValueError("only rectangular Amoeba candidate manifests are supported")
    if header.get("spatial_capacity_policy") != SPATIAL_CAPACITY_POLICY:
        raise ValueError("candidate manifest spatial capacity policy mismatch")
    if footer.get("candidate_count") != len(candidates):
        raise ValueError("candidate manifest footer count mismatch")
    architecture = _object(header.get("architecture"), "header architecture")
    grid_rows = _positive_integer(architecture.get("grid_rows"), "grid_rows")
    grid_cols = _positive_integer(architecture.get("grid_cols"), "grid_cols")
    per_rows = _positive_integer(
        architecture.get("per_cgra_tile_rows"), "per_cgra_tile_rows",
    )
    per_cols = _positive_integer(
        architecture.get("per_cgra_tile_cols"), "per_cgra_tile_cols",
    )
    shape_protocol = get_shape_protocol_for_per_cgra(per_rows, per_cols)
    architecture_sha256 = _sha256_string(
        architecture.get("spec_sha256"), "architecture spec_sha256",
    )
    max_cgras_per_task = _positive_integer(
        header.get("max_cgras_per_task"), "max_cgras_per_task",
    )
    if max_cgras_per_task > shape_protocol.max_physical_cgras:
        raise ValueError(
            f"shape protocol {shape_protocol.protocol_id} supports at most "
            f"{shape_protocol.max_physical_cgras} physical CGRAs per task"
        )
    shape_alphabet = _static_shape_alphabet(
        grid_rows, grid_cols, max_cgras_per_task,
    )

    raw_tasks = header.get("tasks")
    if not isinstance(raw_tasks, list) or not raw_tasks:
        raise ValueError("candidate manifest has no task facts")
    task_facts = []
    task_names = set()
    for raw_task in raw_tasks:
        task = _object(raw_task, "task fact")
        name = task.get("task")
        if not isinstance(name, str) or not name or name in task_names:
            raise ValueError("candidate manifest task names must be unique")
        task_names.add(name)
        task_facts.append((
            name,
            _sha256_string(task.get("body_sha256"), "task body_sha256"),
            _positive_integer(task.get("trip_count"), "task trip_count"),
        ))
    task_body_sha256 = {name: body_sha for name, body_sha, _ in task_facts}

    raw_queries = header.get("cost_queries")
    if not isinstance(raw_queries, list) or not raw_queries:
        raise ValueError("candidate manifest has no cost_queries")
    queries: List[QueryKey] = []
    seen = set()
    for raw in raw_queries:
        query = _object(raw, "cost query")
        task = query.get("task")
        if not isinstance(task, str) or not task:
            raise ValueError("cost query task is missing")
        rows = _positive_integer(query.get("mapper_tile_rows"), "mapper_tile_rows")
        cols = _positive_integer(query.get("mapper_tile_cols"), "mapper_tile_cols")
        key = (task, rows, cols)
        if key in seen:
            raise ValueError("duplicate cost query")
        seen.add(key)
        queries.append(key)

    task_order = [fact[0] for fact in task_facts]
    for task, _, _ in queries:
        if task not in task_names:
            raise ValueError("cost query names a task outside header task facts")

    candidate_queries = set()
    expected_tuples = iter(_packable_shape_index_tuples(
        len(task_order), shape_alphabet, grid_rows, grid_cols,
    ))
    for candidate_index, candidate in enumerate(candidates):
        candidate_id = candidate.get("candidate_id")
        if candidate_id != f"candidate-{candidate_index}":
            raise ValueError(
                "candidate identity does not match its canonical manifest index"
            )
        task_shapes = candidate.get("task_shapes")
        if not isinstance(task_shapes, list) or not task_shapes:
            raise ValueError("candidate has no task_shapes")
        if len(task_shapes) != len(task_facts):
            raise ValueError("candidate task count does not match header")
        actual_shapes = []
        for task_index, raw_choice in enumerate(task_shapes):
            choice = _object(raw_choice, "candidate task shape")
            task = choice.get("task")
            expected_task, _, expected_trip_count = task_facts[task_index]
            if task != expected_task or choice.get("trip_count") != expected_trip_count:
                raise ValueError("candidate task facts do not match header")
            shape = _object(choice.get("shape"), "candidate shape")
            if shape.get("kind") != "rect":
                raise ValueError("non-rectangular candidate shape is unsupported")
            physical_rows = _positive_integer(shape.get("rows"), "shape rows")
            physical_cols = _positive_integer(shape.get("cols"), "shape cols")
            if shape.get("cgra_count") != physical_rows * physical_cols:
                raise ValueError("candidate physical CGRA count is invalid")
            if shape.get("cgra_shape") != f"{physical_rows}x{physical_cols}":
                raise ValueError("candidate physical shape label is invalid")
            mapper_rows = _positive_integer(
                shape.get("mapper_tile_rows"), "shape mapper_tile_rows",
            )
            mapper_cols = _positive_integer(
                shape.get("mapper_tile_cols"), "shape mapper_tile_cols",
            )
            if (mapper_rows, mapper_cols) != (
                physical_rows * per_rows, physical_cols * per_cols,
            ):
                raise ValueError("candidate physical-to-mapper conversion is invalid")
            try:
                shape_protocol.validate_physical_shape(
                    physical_rows, physical_cols,
                )
            except ValueError as error:
                raise ValueError(
                    "candidate physical shape is outside its registered "
                    f"shape protocol: {physical_rows}x{physical_cols}"
                ) from error
            actual_shapes.append((physical_rows, physical_cols))
            candidate_queries.add((task, mapper_rows, mapper_cols))
        try:
            expected_indices = next(expected_tuples)
        except StopIteration as error:
            raise ValueError(
                "candidate manifest contains more than the packable shape space"
            ) from error
        expected_shapes = [shape_alphabet[index] for index in expected_indices]
        if actual_shapes != expected_shapes:
            raise ValueError(
                "candidate manifest is incomplete, unpackable, duplicated, "
                "or out of order"
            )
    try:
        next(expected_tuples)
    except StopIteration:
        pass
    else:
        raise ValueError("candidate manifest omits packable shape tuples")
    if candidate_queries != seen:
        raise ValueError("header cost_queries do not match candidate task shapes")
    return {
        "header": dict(header),
        "candidates": [dict(candidate) for candidate in candidates],
        "candidate_count": len(candidates),
        "queries": queries,
        "task_body_sha256": task_body_sha256,
        "architecture_sha256": architecture_sha256,
        "manifest_sha256": sha256_file(path),
        "shape_protocol": shape_protocol.protocol_id,
    }


def load_analytical_input(
    path: Path, expected_function: str,
) -> Tuple[Dict[QueryKey, Dict[str, float]], Dict[str, Any]]:
    root = _object(json.loads(path.read_text()), "analytical input")
    if root.get("schema") != ANALYTICAL_INPUT_SCHEMA:
        raise ValueError("analytical input schema mismatch")
    if root.get("function") != expected_function:
        raise ValueError("analytical input function mismatch")
    provenance = dict(_object(
        root.get("provenance"), "analytical input provenance",
    ))
    entries = root.get("entries")
    if not isinstance(entries, list):
        raise ValueError("analytical input entries must be an array")
    result: Dict[QueryKey, Dict[str, float]] = {}
    for raw in entries:
        entry = _object(raw, "analytical entry")
        task = entry.get("task")
        if not isinstance(task, str) or not task:
            raise ValueError("analytical entry task is missing")
        rows = _positive_integer(entry.get("mapper_tile_rows"), "mapper_tile_rows")
        cols = _positive_integer(entry.get("mapper_tile_cols"), "mapper_tile_cols")
        # Neura uses RecMII=1 when no recurrence exists, but preserves
        # RecMII=0 for a present zero-length recurrence cycle made only from
        # non-materialized reserve/movement operations. A scoreable task still
        # needs positive ResMII, lower bound, and startup cycles.
        rec_mii = _nonnegative_number(entry.get("rec_mii"), "rec_mii")
        res_mii = _positive_number(entry.get("res_mii"), "res_mii")
        lower_bound = _positive_number(entry.get("lower_bound"), "lower_bound")
        startup = _positive_number(entry.get("startup_cycles"), "startup_cycles")
        if lower_bound != max(rec_mii, res_mii):
            raise ValueError("analytical lower_bound must equal max(RecMII, ResMII)")
        key = (task, rows, cols)
        if key in result:
            raise ValueError("duplicate analytical query")
        result[key] = {
            "rec_mii": rec_mii,
            "res_mii": res_mii,
            "lower_bound": lower_bound,
            "startup_cycles": startup,
        }
    return result, provenance


def parse_task_paths(values: Iterable[str]) -> Dict[str, Path]:
    result: Dict[str, Path] = {}
    for value in values:
        task, separator, raw_path = value.partition("=")
        if not separator or not task or not raw_path:
            raise ValueError("task DFG must be TASK=PATH")
        if task in result:
            raise ValueError(f"duplicate DFG path for task {task}")
        path = Path(raw_path).resolve()
        if not path.is_file():
            raise ValueError(f"task DFG does not exist: {path}")
        result[task] = path
    return result


def load_mapper_model(
    path: Path, device: torch.device,
) -> Tuple[torch.nn.Module, MapperModelConfig, Dict[str, Any]]:
    """Strictly load the one fixed-heuristic mapper surrogate."""
    artifact = torch.load(path, map_location=device, weights_only=False)
    if not isinstance(artifact, Mapping) or artifact.get("schema") not in {
        CHECKPOINT_SCHEMA, CATEGORICAL_CHECKPOINT_SCHEMA,
        RIDGE_CHECKPOINT_SCHEMA, ENSEMBLE_CHECKPOINT_SCHEMA,
    }:
        raise ValueError("mapper checkpoint has an unsupported schema")
    checkpoint_features = artifact.get("feature_names")
    raw_config = _object(artifact.get("config"), "mapper model config")
    feature_names = mapper_feature_names(
        raw_config.get("shape_protocol", SHAPE_PROTOCOL_ID)
    )
    ridge = artifact["schema"] == RIDGE_CHECKPOINT_SCHEMA
    ensemble = artifact["schema"] == ENSEMBLE_CHECKPOINT_SCHEMA
    legacy_features = checkpoint_features != list(feature_names)
    if legacy_features:
        if (ridge or ensemble or
                raw_config.get("shape_protocol", SHAPE_PROTOCOL_ID) != SHAPE_PROTOCOL_ID):
            raise ValueError(
                "ridge and ensemble checkpoints require the current feature contract"
            )
        # The deployed 112-feature checkpoint predates the current 156-feature
        # training contract. Embed its original normalization and input layer
        # without changing any learned weight or allowing arbitrary reordering.
        if (not isinstance(checkpoint_features, list) or
                len(checkpoint_features) != 112 or
                len(set(checkpoint_features)) != 112 or
                checkpoint_features != [name for name in MAPPER_FEATURE_NAMES
                                        if name in checkpoint_features]):
            raise ValueError("mapper checkpoint feature contract mismatch")
    if legacy_features:
        if "enabled_feature_names" in raw_config:
            raise ValueError("legacy checkpoint has an unexpected feature mask")
        raw_config = {**raw_config, "enabled_feature_names": checkpoint_features}
    config = MapperModelConfig(**raw_config).validate()
    categorical = artifact["schema"] == CATEGORICAL_CHECKPOINT_SCHEMA
    expected_output_mode = "categorical" if categorical else "continuous"
    if artifact.get("output_mode", expected_output_mode) != expected_output_mode:
        raise ValueError("mapper checkpoint output mode is inconsistent")
    if ensemble:
        member_count = _positive_integer(
            artifact.get("ensemble_member_count"), "ensemble member count",
        )
        if member_count < 2:
            raise ValueError("ensemble requires at least two members")
        if artifact.get("ensemble_reduction") != "arithmetic_mean":
            raise ValueError("ensemble reduction must be arithmetic_mean")
    model = (
        RidgeMapperIIModel(config) if ridge else
        CategoricalMapperIIModel(config) if categorical else
        DirectMapperIIEnsemble(member_count, config) if ensemble else
        DirectMapperIIModel(config)
    ).to(device)
    state_dict = artifact["state_dict"]
    if ridge:
        required = model.state_dict()
        if (not isinstance(state_dict, Mapping) or
                set(state_dict) != set(required)):
            raise ValueError("ridge checkpoint state keys are invalid")
        for key, expected in required.items():
            value = state_dict[key]
            if (not isinstance(value, torch.Tensor) or
                    value.shape != expected.shape or
                    value.dtype != torch.float64 or
                    not torch.isfinite(value).all()):
                raise ValueError(f"ridge checkpoint {key} is invalid")
        if not torch.all(state_dict["feature_scale"] > 0):
            raise ValueError("ridge checkpoint feature scales must be positive")
    if ensemble:
        required = model.state_dict()
        if (not isinstance(state_dict, Mapping) or
                set(state_dict) != set(required)):
            raise ValueError("ensemble checkpoint state keys are invalid")
        for key, expected in required.items():
            value = state_dict[key]
            if (not isinstance(value, torch.Tensor) or
                    value.shape != expected.shape or
                    value.dtype != expected.dtype or
                    not torch.isfinite(value).all()):
                raise ValueError(f"ensemble checkpoint {key} is invalid")
        for index in range(member_count):
            if not torch.all(state_dict[f"members.{index}.feature_scale"] > 0):
                raise ValueError("ensemble feature scales must be positive")
    if legacy_features:
        state_dict = dict(state_dict)
        for key, fill in (("feature_mean", 0.0), ("feature_scale", 1.0)):
            original = state_dict[key]
            if original.shape != (112,):
                raise ValueError("legacy checkpoint normalization width mismatch")
            expanded = torch.full((len(MAPPER_FEATURE_NAMES),), fill,
                                  dtype=original.dtype, device=original.device)
            positions = {name: index for index, name in enumerate(MAPPER_FEATURE_NAMES)}
            for index, name in enumerate(checkpoint_features):
                expanded[positions[name]] = original[index]
            state_dict[key] = expanded
    model.load_state_dict(state_dict, strict=True)
    model.eval()
    architecture = _sha256_string(
        artifact.get("architecture_sha256"), "training architecture SHA-256",
    )
    raw_supported = artifact.get("supported_architecture_sha256", [architecture])
    if not isinstance(raw_supported, list) or not raw_supported:
        raise ValueError("mapper checkpoint architecture allowlist is invalid")
    supported = [
        _sha256_string(value, "supported architecture SHA-256")
        for value in raw_supported
    ]
    if architecture not in supported or len(set(supported)) != len(supported):
        raise ValueError("mapper checkpoint architecture allowlist is inconsistent")
    compatibility_rule = artifact.get(
        "architecture_compatibility_rule", "exact_architecture_sha256",
    )
    if not isinstance(compatibility_rule, str) or not compatibility_rule:
        raise ValueError("mapper checkpoint compatibility rule is invalid")
    architecture_contract = {
        "training_architecture_sha256": architecture,
        "supported_architecture_sha256": supported,
        "compatibility_rule": compatibility_rule,
    }
    raw_shapes = artifact.get("supported_mapper_shapes")
    if raw_shapes is None:
        supported_shapes = list(get_shape_protocol(
            config.shape_protocol).mapper_shapes)
        if legacy_features:
            # The original checkpoint only observed its eight shape features.
            supported_shapes = [
                shape for shape in supported_shapes
                if f"shape_{shape[0]}x{shape[1]}" in checkpoint_features
            ]
    else:
        if not isinstance(raw_shapes, list) or not raw_shapes:
            raise ValueError("supported mapper shapes must be a nonempty list")
        supported_shapes = []
        protocol_shapes = set(get_shape_protocol(config.shape_protocol).mapper_shapes)
        for raw_shape in raw_shapes:
            if (not isinstance(raw_shape, (list, tuple)) or len(raw_shape) != 2):
                raise ValueError("supported mapper shape must contain rows and cols")
            shape = (
                _positive_integer(raw_shape[0], "supported mapper rows"),
                _positive_integer(raw_shape[1], "supported mapper cols"),
            )
            if shape not in protocol_shapes or shape in supported_shapes:
                raise ValueError("supported mapper shape is invalid or duplicated")
            supported_shapes.append(shape)
    return model, config, {
        "contract_id": (
            "cgra-ii-architecture-" +
            canonical_json_sha256(architecture_contract)[:24]
        ),
        "sha256": sha256_file(path),
        "training_manifest_sha256": _sha256_string(
            artifact.get("training_manifest_sha256"),
            "training manifest SHA-256",
        ),
        "training_architecture_sha256": architecture,
        "supported_architecture_sha256": supported,
        "compatibility_rule": compatibility_rule,
        "config_sha256": canonical_json_sha256(config.to_dict()),
        "output_mode": expected_output_mode,
        "deployment_readout": artifact.get(
            "deployment_readout",
            "argmax_integer_residual_class" if categorical
            else "bounded_continuous_regression",
        ),
        "ranking_readout": artifact.get(
            "ranking_readout",
            "probability_weighted_expected_ii" if categorical
            else "bounded_continuous_regression",
        ),
        "supported_mapper_shapes": [list(shape) for shape in supported_shapes],
    }


def predict_mapper_ii(
    model: torch.nn.Module, features: torch.Tensor,
    lower_bounds: torch.Tensor, readout: str = "auto",
) -> Tuple[torch.Tensor, str]:
    """Apply a checkpoint's continuous or categorical deployment readout."""
    if readout not in {"auto", "expected", "label"}:
        raise ValueError("mapper II readout must be auto, expected, or label")
    if isinstance(model, CategoricalMapperIIModel):
        effective = "label" if readout == "auto" else readout
        values = (
            model.predict_label(features, lower_bounds)
            if effective == "label" else model(features, lower_bounds)
        )
        return values, effective
    if readout == "label":
        raise ValueError(
            "integer label readout requires a categorical mapper checkpoint"
        )
    return model(features, lower_bounds), "continuous"


def validate_model_architecture(
    model_metadata: Mapping[str, Any], architecture_sha256: object,
) -> None:
    supported = model_metadata["supported_architecture_sha256"]
    if architecture_sha256 not in supported:
        raise ValueError(
            "analytical architecture is outside the deployed model contract"
        )


def generate_catalog(
    candidate_manifest: Path, analytical_input: Path,
    task_paths: Mapping[str, Path], model_path: Path, device: torch.device,
    ii_readout: str = "auto",
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    total_started = time.perf_counter()
    manifest = load_candidate_manifest(candidate_manifest)
    header = manifest["header"]
    function = str(header["function"])
    analytical, analytical_provenance = load_analytical_input(
        analytical_input, function,
    )
    if analytical_provenance.get("candidate_manifest_sha256") != (
        manifest["manifest_sha256"]
    ):
        raise ValueError("analytical input candidate manifest SHA-256 mismatch")
    if analytical_provenance.get("architecture_sha256") != (
        manifest["architecture_sha256"]
    ):
        raise ValueError("analytical input architecture does not match manifest")
    tasks = sorted({task for task, _, _ in manifest["queries"]})
    if set(task_paths) != set(tasks):
        raise ValueError("task DFG mapping must exactly cover manifest tasks")

    load_started = time.perf_counter()
    model, config, model_metadata = load_mapper_model(model_path, device)
    if config.shape_protocol != manifest["shape_protocol"]:
        raise ValueError(
            "mapper checkpoint shape protocol does not match candidate manifest"
        )
    architecture_sha256 = analytical_provenance.get("architecture_sha256")
    validate_model_architecture(model_metadata, architecture_sha256)
    model_load_ms = (time.perf_counter() - load_started) * 1000.0

    parse_started = time.perf_counter()
    graphs = {}
    task_identities = {}
    for task in tasks:
        path = task_paths[task]
        task_identities[task] = sha256_file(path)
        dfg_text = path.read_text()
        source_body_sha = source_task_body_sha256(dfg_text, task)
        if source_body_sha != manifest["task_body_sha256"][task]:
            raise ValueError(
                f"task DFG source body hash mismatch for {task}"
            )
        graphs[task] = require_neura_route_expanded_dfg(dfg_text)
    provenance_task_hashes = _object(
        analytical_provenance.get("task_dfg_sha256"),
        "analytical provenance task DFG hashes",
    )
    if provenance_task_hashes != task_identities:
        raise ValueError("analytical input task DFG SHA-256 mismatch")
    provenance_body_hashes = _object(
        analytical_provenance.get("task_body_sha256"),
        "analytical provenance task body hashes",
    )
    if provenance_body_hashes != manifest["task_body_sha256"]:
        raise ValueError("analytical input task body SHA-256 mismatch")
    for field in (
        "neura_opt_sha256", "architecture_sha256",
        "rec_res_source", "startup_cycles_source",
    ):
        if not isinstance(analytical_provenance.get(field), str) or not (
            analytical_provenance[field]
        ):
            raise ValueError(f"analytical input provenance lacks {field}")
    dfg_parse_ms = (time.perf_counter() - parse_started) * 1000.0

    model_shapes = {
        tuple(shape) for shape in model_metadata["supported_mapper_shapes"]
    }
    supported_queries = [
        key for key in manifest["queries"]
        if (key[1], key[2]) in model_shapes
    ]
    unsupported_queries = {
        key for key in manifest["queries"] if key not in supported_queries
    }
    if any(key not in analytical for key in supported_queries):
        missing = next(key for key in supported_queries if key not in analytical)
        raise ValueError(f"supported query lacks analytical input: {missing}")
    extra_analytical = set(analytical).difference(manifest["queries"])
    if extra_analytical:
        raise ValueError("analytical input contains queries outside the manifest")

    inference_started = time.perf_counter()
    predictions: Dict[QueryKey, float] = {}
    categorical_labels: Dict[QueryKey, int] = {}
    categorical_expectations: Dict[QueryKey, float] = {}
    effective_readout = "continuous"
    inference_dtype = (
        torch.float64 if isinstance(model, RidgeMapperIIModel)
        else torch.float32
    )
    with torch.inference_mode():
        for offset in range(0, len(supported_queries), 4096):
            keys = supported_queries[offset:offset + 4096]
            features = torch.tensor([
                mapper_feature_vector(
                    graphs[task], rows, cols,
                    analytical[key]["rec_mii"],
                    analytical[key]["res_mii"],
                    analytical[key]["lower_bound"],
                    mapper_ii_ceiling=config.mapper_ii_ceiling,
                    shape_protocol=config.shape_protocol,
                )
                for key in keys for task, rows, cols in (key,)
            ], dtype=inference_dtype, device=device)
            lower_bounds = torch.tensor([
                analytical[key]["lower_bound"] for key in keys
            ], dtype=inference_dtype, device=device)
            if isinstance(model, CategoricalMapperIIModel):
                logits = model.class_logits(features, lower_bounds)
                expected = model.expected_ii_from_logits(logits, lower_bounds)
                labels = torch.round(lower_bounds).to(dtype=torch.int64) + (
                    torch.argmax(logits, dim=1)
                )
                effective_readout = (
                    "label" if ii_readout == "auto" else ii_readout
                )
                values = labels if effective_readout == "label" else expected
                categorical_labels.update(zip(
                    keys, map(int, labels.detach().cpu().tolist()),
                ))
                categorical_expectations.update(zip(
                    keys, map(float, expected.detach().cpu().tolist()),
                ))
            else:
                values, effective_readout = predict_mapper_ii(
                    model, features, lower_bounds, ii_readout,
                )
            values = values.detach().cpu().tolist()
            predictions.update(zip(keys, map(float, values)))
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    inference_ms = (time.perf_counter() - inference_started) * 1000.0

    entries = []
    cache_keys = set()
    for key in manifest["queries"]:
        task, rows, cols = key
        cache_key = (task_identities[task], rows, cols)
        cache_keys.add(cache_key)
        entry: Dict[str, Any] = {
            "task": task,
            "mapper_tile_rows": rows,
            "mapper_tile_cols": cols,
        }
        if key in unsupported_queries:
            entry["support_status"] = "unsupported"
        else:
            entry.update({
                "support_status": "supported",
                "predicted_ii": predictions[key],
                "startup_cycles": analytical[key]["startup_cycles"],
                "analytical_lower_bound": analytical[key]["lower_bound"],
                "ii_mean_source": (
                    "categorical_mapper_surrogate_argmax"
                    if effective_readout == "label"
                    else "ridge_mapper_surrogate"
                    if isinstance(model, RidgeMapperIIModel)
                    else "direct_mapper_surrogate"
                ),
            })
            if key in categorical_labels:
                entry.update({
                    "predicted_ii_label": categorical_labels[key],
                    "predicted_ii_expected": categorical_expectations[key],
                })
        entries.append(entry)

    namespace_contract = {
        "feature_schema": ADAPTER_FEATURE_SCHEMA,
        "shape_protocol": get_shape_protocol(
            config.shape_protocol
        ).to_dict(),
        "candidate_manifest_sha256": manifest["manifest_sha256"],
        "analytical_input_sha256": sha256_file(analytical_input),
        "analytical_provenance": {
            "neura_opt_sha256": analytical_provenance["neura_opt_sha256"],
            "architecture_sha256": analytical_provenance[
                "architecture_sha256"
            ],
            "task_body_sha256": manifest["task_body_sha256"],
            "task_dfg_sha256": task_identities,
            "rec_res_source": analytical_provenance["rec_res_source"],
            "startup_cycles_source": analytical_provenance[
                "startup_cycles_source"
            ],
        },
        "model": model_metadata,
        "architecture_contract": model_metadata,
        "ii_readout": effective_readout,
        "ranking_policy": {
            "objective": "predicted_compute_bottleneck",
            "mapper_success_probability": "not_predicted",
            "uses_mapper_success_probability": False,
        },
    }
    namespace_hash = canonical_json_sha256(namespace_contract)
    catalog = {
        "schema": COST_SCHEMA,
        "function": function,
        "namespace": f"cgra-ii-direct-mapper-{namespace_hash[:24]}",
        "predictor_metadata": namespace_contract,
        "entries": entries,
    }
    timing = {
        "model_load_ms": model_load_ms,
        "dfg_parse_ms": dfg_parse_ms,
        "steady_state_inference_ms": inference_ms,
        "steady_state_ms_per_supported_query": (
            inference_ms / len(supported_queries) if supported_queries else None
        ),
        "total_ms": (time.perf_counter() - total_started) * 1000.0,
        "manifest_candidate_count": manifest["candidate_count"],
        "unique_cost_query_count": len(manifest["queries"]),
        "unique_cache_entry_count": len(cache_keys),
        "supported_query_count": len(supported_queries),
        "unsupported_query_count": len(unsupported_queries),
        "task_dfg_parse_count": len(graphs),
        "model_load_count": 1,
        "model_forward_pass_count": math.ceil(len(supported_queries) / 4096),
    }
    return catalog, timing


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--analytical-input", type=Path, required=True)
    parser.add_argument(
        "--task-dfg", action="append", default=[], metavar="TASK=PATH",
        help="Pre-mapper Neura DFG; repeat exactly once for each manifest task.",
    )
    parser.add_argument("--model", type=Path, default=DEFAULT_MODEL)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--timing-output", type=Path)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument(
        "--ii-readout", choices=("auto", "expected", "label"),
        default="auto",
        help="Categorical checkpoints default to integer argmax labels; use "
             "expected to retain probability-weighted ranking scores.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    task_paths = parse_task_paths(args.task_dfg)
    catalog, timing = generate_catalog(
        args.manifest.resolve(), args.analytical_input.resolve(),
        task_paths, args.model.resolve(), torch.device(args.device),
        args.ii_readout,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(catalog, indent=2, sort_keys=True, allow_nan=False) + "\n"
    )
    if args.timing_output is not None:
        args.timing_output.parent.mkdir(parents=True, exist_ok=True)
        args.timing_output.write_text(
            json.dumps(timing, indent=2, sort_keys=True, allow_nan=False) + "\n"
        )
    print(json.dumps({
        "output": str(args.output.resolve()),
        "namespace": catalog["namespace"],
        **timing,
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
