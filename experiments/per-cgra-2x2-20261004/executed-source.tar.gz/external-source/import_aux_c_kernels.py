#!/usr/bin/env python3
"""Freeze pinned C/C++ benchmark kernel DFGs for auxiliary screening."""

from __future__ import annotations

import argparse
from collections import defaultdict
import json
from pathlib import Path
import re
import subprocess
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
for source in (ROOT / "adapters", ROOT / "src"):
    if str(source) not in sys.path:
        sys.path.insert(0, str(source))

from amoeba_cost_catalog import canonical_json_sha256, sha256_file
from evaluate_static_dl_ii import mapper_input_identity
from cgra_ii_predictor.dfg import require_neura_route_expanded_dfg


SCHEMA = "cgra-ii-aux-kernel-import-v1"
REVISIONS = {
    "cgra-bench": "6729aaf225d0320e4e0d3b419e20483069a5a69b",
    "cgra-bench-o0-repair": "6729aaf225d0320e4e0d3b419e20483069a5a69b",
    "cgra-streaming-gcn": "6729aaf225d0320e4e0d3b419e20483069a5a69b",
    "cgra-streaming-lu": "6729aaf225d0320e4e0d3b419e20483069a5a69b",
    "machsuite": "6236e593012cb86b0d2f08d9fb9ba0411ff989b4",
    "zeonica-new": "2cccc700e73f584eb7d4ab4374722b9a7f8ec196",
    "polybench-c": "d3a15bb1725afaaa33bcf3a4db6087ebf557c9b8",
    "polybench-o0-repair": "d3a15bb1725afaaa33bcf3a4db6087ebf557c9b8",
    "taclebench-v1.9": "a298a41a3d4cc79189c1320a03f87cdc43175771",
    "taclebench-v1.9-inline": "a298a41a3d4cc79189c1320a03f87cdc43175771",
    "embench-iot-1.0": "0466a18e4f6b47e19598d7c6ba72916d54b68f65",
    "embench-iot-1.0-o0-sha": "0466a18e4f6b47e19598d7c6ba72916d54b68f65",
    "embench-iot-1.0-qr-align": "0466a18e4f6b47e19598d7c6ba72916d54b68f65",
    "embench-iot-1.0-nbody-offset": "0466a18e4f6b47e19598d7c6ba72916d54b68f65",
    "hls-eval-c2hlsc-small": "9eb7addc7103b44d25eee61fc356e3f50cfc28e9",
    "hls-eval-chstone-bitutils": "9eb7addc7103b44d25eee61fc356e3f50cfc28e9",
    "hls-eval-gnn-small": "9eb7addc7103b44d25eee61fc356e3f50cfc28e9",
}
EMBENCH_STATIC_CANDIDATES = (
    ("nettle-sha256", "src/nettle-sha256/nettle-sha256.c",
     "_nettle_sha256_compress", ("global/hash", "upstream/nettle"),
     "constant_bound"),
    ("nettle-aes", "src/nettle-aes/nettle-aes.c",
     "_nettle_aes_encrypt", ("global/aes", "upstream/nettle"),
     "symbol_bound"),
    ("nsichneu", "src/nsichneu/libnsichneu.c",
     "benchmark_body", ("global/state-machine", "upstream/clab-nsichneu"),
     "symbol_bound"),
)
TACLE_KERNELS = (
    "binarysearch", "bitonic", "bsort", "complex_updates", "countnegative",
    "crc", "fac", "fft", "filterbank", "fir2dim", "iir", "insertsort",
    "jfdctint", "lms", "ludcmp", "matrix1", "md5", "minver", "prime",
    "st",
)
MACH_TOPS = (
    ("aes/aes", "aes/aes/aes.c", "aes256_encrypt_ecb"),
    ("backprop/backprop", "backprop/backprop/backprop.c", "backprop"),
    ("bfs/bulk", "bfs/bulk/bfs.c", "bfs"),
    ("bfs/queue", "bfs/queue/bfs.c", "bfs"),
    ("fft/strided", "fft/strided/fft.c", "fft"),
    ("fft/transpose", "fft/transpose/fft.c", "fft1D_512"),
    ("gemm/blocked", "gemm/blocked/gemm.c", "bbgemm"),
    ("gemm/ncubed", "gemm/ncubed/gemm.c", "gemm"),
    ("kmp/kmp", "kmp/kmp/kmp.c", "kmp"),
    ("md/grid", "md/grid/md.c", "md"),
    ("md/knn", "md/knn/md.c", "md_kernel"),
    ("nw/nw", "nw/nw/nw.c", "needwun"),
    ("sort/merge", "sort/merge/sort.c", "ms_mergesort"),
    ("sort/radix", "sort/radix/sort.c", "ss_sort"),
    ("spmv/crs", "spmv/crs/spmv.c", "spmv"),
    ("spmv/ellpack", "spmv/ellpack/spmv.c", "ellpack"),
    ("stencil/stencil2d", "stencil/stencil2d/stencil.c", "stencil"),
    ("stencil/stencil3d", "stencil/stencil3d/stencil.c", "stencil3d"),
    ("viterbi/viterbi", "viterbi/viterbi/viterbi.c", "viterbi"),
)
ZEONICA_NEW_TOPS = (
    ("axpy/axpy_int.cpp", "kernel_axpy_int"),
    ("gemv/gemv_int.cpp", "kernel_gemv_int"),
    ("sad/sad_int.c", "kernel_sad_int"),
)
CGRA_STREAMING_GCN_TOPS = (
    ("aggregate1/aggregate.c", "kernel"),
    ("combine/combine.c", "kernel"),
    ("combineRelu/combineRelu.c", "kernel"),
    ("compress/compress.cpp", "_Z6kerneliPPiS_S_S_"),
    ("pooling/pool.c", "kernel"),
)
CGRA_STREAMING_LU_SOURCES = (
    "init/kernel.cpp",
    "decompose/kernel.cpp",
    "invert/kernel.cpp",
    "determinant/kernel.cpp",
    "solver0/kernel.cpp",
    "solver1/kernel.cpp",
)


def _revision(source_root: Path, suite: str) -> str:
    actual = subprocess.check_output(["git", "-C", str(source_root), "rev-parse", "HEAD"],
                                     text=True).strip()
    if actual != REVISIONS[suite]:
        raise ValueError(f"{suite} revision changed: {actual}")
    if subprocess.check_output(["git", "-C", str(source_root), "status", "--porcelain"],
                               text=True).strip():
        raise ValueError(f"{suite} checkout has uncommitted changes")
    return actual


def _inventory(suite: str, source_root: Path) -> list[dict[str, Any]]:
    if suite == "hls-eval-gnn-small":
        candidates = (
            ("gnnbuilder", "global_add_pool", "global_add_pool",
             "_Z15global_add_pooliPA16_fPf", "symbol_bound",
             ["upstream/gnnbuilder", "global/gnn-pooling"]),
            ("gnnbuilder", "gather_node_neighbors", "gather_node_neighbors",
             "_Z21gather_node_neighborsiiPiS_S_", "symbol_bound",
             ["upstream/gnnbuilder", "global/gnn-neighbor-gather"]),
            ("flowgnn", "fgnn_linear", "linear",
             "_Z6linearPfPA32_fS_S_", "constant_bound",
             ["upstream/flowgnn", "global/gemm"]),
        )
        rows = []
        for upstream, directory, kernel, top, bound, families in candidates:
            relative = f"hls_eval_data/{upstream}/{directory}/{kernel}.cpp"
            path = source_root / relative
            if not path.is_file():
                raise ValueError(f"pinned HLS-Eval source missing: {relative}")
            rows.append({
                "case_id": f"hls-eval/{upstream}/{kernel}",
                "source_path": str(path),
                "source_relative_path": relative,
                "top": top,
                "source_program_families": families,
                "source_bound_classification": bound,
                "source_admission_status": "pending_cpu_frontend_and_semantic_audit",
            })
        return rows
    if suite == "hls-eval-chstone-bitutils":
        rows = []
        for name, top in (
                ("df_mul64To128", "_Z10mul64To128yyPyS_"),
                ("df_countLeadingZeros64", "_Z19countLeadingZeros64y"),
                ("df_countLeadingZeros32", "_Z19countLeadingZeros32j")):
            kernel = name.removeprefix("df_")
            relative = f"hls_eval_data/chstone/{name}/{kernel}.cpp"
            path = source_root / relative
            if not path.is_file():
                raise ValueError(f"pinned HLS-Eval source missing: {relative}")
            rows.append({
                "case_id": f"hls-eval/chstone/{kernel}",
                "source_path": str(path),
                "source_relative_path": relative,
                "top": top,
                "source_program_families": ["upstream/chstone"],
                "source_bound_classification": "straight_line",
                "source_admission_status": "pending_cpu_frontend_and_semantic_audit",
            })
        return rows
    if suite == "hls-eval-c2hlsc-small":
        rows = []
        for name, top in (("monobit", "_Z9FrequencyPiS_"),
                          ("runs", "_Z4RunsPiS_S_")):
            relative = f"hls_eval_data/c2hlsc/{name}/{name}.cpp"
            path = source_root / relative
            if not path.is_file():
                raise ValueError(f"pinned HLS-Eval source missing: {relative}")
            rows.append({
                "case_id": f"hls-eval/c2hlsc/{name}",
                "source_path": str(path),
                "source_relative_path": relative,
                "top": top,
                "source_program_families": [
                    "global/randomness-test", "upstream/c2hlsc"],
                "source_bound_classification": "constant_bound",
                "source_admission_status": "pending_cpu_frontend_and_semantic_audit",
            })
        return rows
    if suite == "embench-iot-1.0-nbody-offset":
        relative = "src/nbody/nbody.c"
        path = source_root / relative
        if not path.is_file():
            raise ValueError(f"pinned Embench source missing: {relative}")
        return [{"case_id": "embench/nbody/offset_momentum",
                 "source_path": str(path),
                 "source_relative_path": relative, "top": "offset_momentum",
                 "source_program_families": ["global/nbody", "upstream/benchmarksgame-nbody"],
                 "source_bound_classification": "symbol_bound",
                 "source_admission_status":
                     "pending_frontend_and_semantic_audit"}]
    if suite == "embench-iot-1.0-qr-align":
        relative = "src/qrduino/qrframe.c"
        path = source_root / relative
        if not path.is_file():
            raise ValueError(f"pinned Embench source missing: {relative}")
        return [{"case_id": "embench/qrduino/putalign",
                 "source_path": str(path),
                 "source_relative_path": relative, "top": "putalign",
                 "source_program_families": ["global/qr-code", "upstream/qrduino"],
                 "source_bound_classification": "constant_bound",
                 "source_admission_status":
                     "pending_frontend_and_semantic_audit"}]
    if suite in {"embench-iot-1.0", "embench-iot-1.0-o0-sha"}:
        rows = []
        candidates = (EMBENCH_STATIC_CANDIDATES[:1]
                      if suite == "embench-iot-1.0-o0-sha"
                      else EMBENCH_STATIC_CANDIDATES)
        for name, relative, top, families, bound in candidates:
            path = source_root / relative
            if not path.is_file():
                raise ValueError(f"pinned Embench source missing: {relative}")
            rows.append({"case_id": f"embench/{name}/{top}",
                         "source_path": str(path),
                         "source_relative_path": relative, "top": top,
                         "source_program_families": list(families),
                         "source_bound_classification": bound,
                         "source_admission_status":
                             "pending_frontend_and_semantic_audit"})
        return rows
    if suite in {"taclebench-v1.9", "taclebench-v1.9-inline"}:
        broad = {
            "binarysearch": "search", "bitonic": "sort", "bsort": "sort",
            "complex_updates": "complex-arithmetic", "countnegative": "statistics",
            "crc": "checksum", "fac": "number-theory", "fft": "fft",
            "filterbank": "filter", "fir2dim": "stencil", "iir": "filter",
            "insertsort": "sort", "jfdctint": "dct", "lms": "filter",
            "ludcmp": "lu", "matrix1": "gemm", "md5": "hash",
            "minver": "matrix-inverse", "prime": "number-theory",
            "st": "statistics",
        }
        rows = []
        for name in TACLE_KERNELS:
            relative = f"bench/kernel/{name}/{name}.c"
            path = source_root / relative
            if not path.is_file():
                raise ValueError(f"pinned TACLeBench source missing: {relative}")
            families = [f"global/{broad[name]}", f"tacle/{name}"]
            if name in {"complex_updates", "iir"}:
                # Both source headers trace to DSPStone. Keep their entire
                # upstream lineage connected in future held-out splits.
                families.append("upstream/dspstone")
            if suite == "taclebench-v1.9-inline" and name in {
                    "countnegative", "st", "bsort", "prime"}:
                families.append("upstream/mrtc")
            rows.append({"case_id": f"tacle/{name}",
                         "source_path": str(path),
                         "source_relative_path": relative,
                         "top": f"{name}_main",
                         "source_program_families": families,
                         "source_admission_status":
                             "pending_source_loop_bound_and_cpu_audit"})
        return rows
    if suite in {"polybench-c", "polybench-o0-repair"}:
        paths = [line.removeprefix("./") for line in
                 (source_root / "utilities" / "benchmark_list").read_text().splitlines()
                 if line.strip()]
        if len(paths) != 30 or len(set(paths)) != 30:
            raise ValueError("pinned PolyBench/C roster must have 30 source files")
        if suite == "polybench-o0-repair":
            paths = [path for path in paths if path.endswith(
                "/floyd-warshall/floyd-warshall.c")]
            if len(paths) != 1:
                raise ValueError("PolyBench/C O0 repair requires Floyd-Warshall")
        gemm_family = {"2mm", "3mm", "doitgen", "gemm", "symm",
                       "syr2k", "syrk", "trmm"}
        stencil_family = {"adi", "fdtd-2d", "heat-3d", "jacobi-1d",
                          "jacobi-2d", "seidel-2d"}
        matvec_family = {"atax", "bicg", "gemver", "gesummv", "mvt"}
        rows = []
        for relative in paths:
            path = source_root / relative
            stem = path.stem
            families = (["global/gemm"] if stem in gemm_family else
                        ["global/stencil"] if stem in stencil_family else
                        ["global/matvec"] if stem in matvec_family else [])
            if stem in {"bicg", "mvt"}:
                families.append(f"global/{stem}")
            families.append(f"polybench/{stem}")
            rows.append({"case_id": f"polybench/{stem}",
                         "source_path": str(path),
                         "source_relative_path": relative,
                         "top": f"kernel_{stem.replace('-', '_')}",
                         "source_program_families": families})
        return rows
    if suite == "machsuite":
        return [{"case_id": case, "source_path": str(source_root / relative),
                 "source_relative_path": relative, "top": top,
                 "source_program_families": [f"global/{case.split('/')[0]}"]}
                for case, relative, top in MACH_TOPS]
    if suite == "zeonica-new":
        return [{"case_id": relative, "source_path": str(source_root / "kernel" /
                                                          relative),
                 "source_relative_path": "kernel/" + relative, "top": top,
                 "source_program_families": [
                     "zeonica/" + relative.split("/")[0]]}
                for relative, top in ZEONICA_NEW_TOPS]
    if suite == "cgra-streaming-gcn":
        return [{"case_id": "gcn/" + relative,
                 "source_path": str(source_root / "Streaming-Bench" / "gcn" /
                                    relative),
                 "source_relative_path": "Streaming-Bench/gcn/" + relative,
                 "top": top,
                 "source_program_families": ["cgra-streaming/gcn"]}
                for relative, top in CGRA_STREAMING_GCN_TOPS]
    if suite == "cgra-streaming-lu":
        return [{"case_id": "lu/" + relative,
                 "source_path": str(source_root / "Streaming-Bench" / "lu" /
                                    relative),
                 "source_relative_path": "Streaming-Bench/lu/" + relative,
                 "top": None,
                 "source_program_families": ["cgra-streaming/lu"]}
                for relative in CGRA_STREAMING_LU_SOURCES]
    if suite == "cgra-bench-o0-repair":
        return [{"case_id": case,
                 "source_path": str(source_root / "kernels" / case),
                 "source_relative_path": "kernels/" + case,
                 "top": None,
                 "source_program_families": [
                     "global/" + case.split("/")[0]]}
                for case in ("dtw/dtw.cpp", "mvt/mvt.c")]
    kernel_root = source_root / "kernels"
    families = sorted(path for path in kernel_root.iterdir() if path.is_dir())
    if len(families) != 15:
        raise ValueError("CGRA-Bench pinned checkout must contain 15 kernel families")
    rows = []
    for family in families:
        for path in sorted(family.iterdir()):
            if path.suffix not in {".c", ".cpp"}:
                continue
            relative = path.relative_to(source_root).as_posix()
            rows.append({"case_id": f"{family.name}/{path.name}",
                         "source_path": str(path),
                         "source_relative_path": relative, "top": None,
                         "source_program_families": [f"global/{family.name}"]})
    return rows


def _visible_identity(text: str) -> str:
    graph = require_neura_route_expanded_dfg(text)
    return canonical_json_sha256({"node_types": graph.node_types,
                                  "edges": graph.edges,
                                  "semantic_edges": graph.semantic_edges})


def _run(command: list[str], stage: str, output: Path, timeout: int) -> None:
    completed = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    if completed.returncode or not output.is_file():
        raise RuntimeError(f"{stage} exit={completed.returncode}: {completed.stderr[-1500:]}")


def _llvm_top(full_ir: Path) -> str:
    names = re.findall(r"^define\s+[^\n]*?@([A-Za-z_.$][A-Za-z_.$0-9]*)\(",
                       full_ir.read_text(), flags=re.MULTILINE)
    kernels = [name for name in names if "kernel" in name.lower()]
    if not kernels:
        raise ValueError("no named kernel entry in compiled source")
    return sorted(kernels, key=lambda name: (len(name), name))[0]


def import_suite(suite: str, source_root: Path, output: Path, architecture: Path,
                 clang: Path, clangxx: Path, llvm_extract: Path,
                 mlir_translate: Path, neura_opt: Path, timeout: int = 90) -> dict:
    source_root = source_root.resolve()
    revision = _revision(source_root, suite)
    if output.exists():
        raise ValueError("auxiliary import output already exists")
    source_rows = _inventory(suite, source_root)
    toolchain = {name: {"path": str(path.resolve()), "sha256": sha256_file(path)}
                 for name, path in (("clang", clang), ("clangxx", clangxx),
                                    ("llvm_extract", llvm_extract),
                                    ("mlir_translate", mlir_translate),
                                    ("neura_opt", neura_opt),
                                    ("architecture", architecture))}
    output.mkdir(parents=True)
    records = []
    identity_groups: dict[str, list[dict]] = defaultdict(list)
    for ordinal, row in enumerate(source_rows):
        case_dir = output / f"case_{ordinal:03d}"
        case_dir.mkdir()
        source = Path(row["source_path"])
        result = {**row, "source_sha256": sha256_file(source),
                  "status": "rejected", "semantic_equivalence_verified": False}
        stage = "compile"
        try:
            full_ir, kernel_ir = case_dir / "full.ll", case_dir / "kernel.ll"
            imported, lowered = case_dir / "imported.mlir", case_dir / "route-expanded.mlir"
            compiler = clangxx if source.suffix == ".cpp" else clang
            standard = "-std=c++17" if source.suffix == ".cpp" else "-std=c11"
            optimization = ("-O0" if suite in {"cgra-bench-o0-repair",
                                              "polybench-o0-repair",
                                              "embench-iot-1.0-o0-sha"}
                            else "-O3")
            command = [str(compiler), "-S", "-emit-llvm", optimization,
                       "-fno-vectorize", "-fno-slp-vectorize", "-fno-unroll-loops",
                       "-Xclang", "-disable-lifetime-markers", standard,
                       "-I", str(source.parent)]
            if suite in {"polybench-c", "polybench-o0-repair",
                         "taclebench-v1.9"}:
                command.append("-fno-inline")
            if suite in {"polybench-c", "polybench-o0-repair"}:
                command.extend(("-I", str(source_root / "utilities")))
            if suite in {"polybench-o0-repair", "embench-iot-1.0-o0-sha"}:
                command.extend(("-Xclang", "-disable-O0-optnone"))
            if suite == "machsuite":
                command.extend(("-I", str(source_root / "common")))
            if suite in {"embench-iot-1.0", "embench-iot-1.0-o0-sha",
                         "embench-iot-1.0-qr-align",
                         "embench-iot-1.0-nbody-offset"}:
                # Only the benchmark harness uses CPU_MHZ. A fixed value
                # compiles the original source without changing core kernels.
                command.extend(("-I", str(source_root / "support"),
                                "-DCPU_MHZ=1"))
            command.extend(("-o", str(full_ir), str(source)))
            _run(command, stage, full_ir, timeout)
            top = row["top"] or _llvm_top(full_ir)
            stage = "extract"
            _run([str(llvm_extract), "--recursive", f"--func={top}",
                  str(full_ir), "-S", "-o", str(kernel_ir)], stage, kernel_ir, timeout)
            stage = "llvm_mlir_import"
            _run([str(mlir_translate), "--import-llvm", str(kernel_ir),
                  "-o", str(imported)], stage, imported, timeout)
            stage = "neura_lower"
            _run([str(neura_opt), str(imported), "--assign-accelerator",
                  "--lower-llvm-to-neura", "--promote-input-arg-to-const",
                  "--fold-constant", "--canonicalize-return", "--canonicalize-live-in",
                  "--leverage-predicated-value", "--transform-ctrl-to-data-flow",
                  "--fold-constant", "--insert-data-mov", "-o", str(lowered)],
                 stage, lowered, timeout)
            stage = "route_dfg_validation"
            text = lowered.read_text()
            require_neura_route_expanded_dfg(text)
            identity = mapper_input_identity(text, normalize_static_shapes=True)
            visible = _visible_identity(text)
            task = {"case_id": row["case_id"], "task": top,
                    "dfg_path": str(lowered.resolve()),
                    "dfg_sha256": sha256_file(lowered),
                    "mapper_input_identity": identity,
                    "model_visible_graph_identity": visible,
                    "source_program_families": row["source_program_families"]}
            result.update(status="accepted", top=top, tasks=[task],
                          frontend_valid=True, semantic_check_scope=(
                              "source-to-LLVM-to-Neura lowering only; independent numerical "
                              "Neura execution unavailable"))
            identity_groups[identity].append(task)
        except Exception as error:
            result.update(failure_stage=stage,
                          reject_reason=f"{type(error).__name__}: {str(error)[-1800:]}")
        records.append(result)
        (case_dir / "audit.json").write_text(json.dumps(result, indent=2,
                                                       sort_keys=True) + "\n")
        print(json.dumps({"case_id": row["case_id"], "status": result["status"],
                          "stage": result.get("failure_stage")}), flush=True)
    manifest = {
        "schema": SCHEMA, "suite": suite, "source_root": str(source_root),
        "upstream_commit": revision, "toolchain": toolchain,
        "source_program_count": len(source_rows),
        "source_family_count": len({family for row in source_rows
                                    for family in row["source_program_families"]}),
        "case_audit": records,
        "accepted_source_cases": sum(row["status"] == "accepted" for row in records),
        "accepted_task_count": sum(len(row.get("tasks", [])) for row in records),
        "mapper_input_identity_mode": "ignore-static-memref-tensor-extents-and-counter-bounds",
        "identity_groups": dict(identity_groups),
        "distinct_mapper_input_dfg_count": len(identity_groups),
        "projected_16_shape_query_count": len(identity_groups) * 16,
        "semantic_equivalence_verified": False,
    }
    if suite in {"cgra-bench-o0-repair", "polybench-o0-repair",
                 "embench-iot-1.0-o0-sha"}:
        manifest["source_llvm_optimization"] = "O0"
    elif suite in {"polybench-c", "taclebench-v1.9",
                        "taclebench-v1.9-inline"}:
        manifest["source_llvm_optimization"] = "O3"
    if suite in {"polybench-c", "polybench-o0-repair", "taclebench-v1.9",
                 "taclebench-v1.9-inline"}:
        manifest["source_compile_policy"] = {
            "preserve_kernel_function": (
                "externally_visible_source_entrypoint"
                if suite == "taclebench-v1.9-inline" else "-fno-inline"),
            "allow_helper_inlining": suite == "taclebench-v1.9-inline",
            "disable_vectorization": ["-fno-vectorize", "-fno-slp-vectorize"],
            "disable_loop_unrolling": "-fno-unroll-loops",
            "disable_lifetime_markers": "-Xclang -disable-lifetime-markers",
            "disable_o0_optnone": suite == "polybench-o0-repair",
            "include_dir": (str(source_root / "utilities")
                            if suite in {"polybench-c", "polybench-o0-repair"}
                            else None),
        }
    manifest["manifest_sha256"] = canonical_json_sha256(manifest)
    (output / "import-manifest.json").write_text(json.dumps(manifest, indent=2,
                                                      sort_keys=True) + "\n")
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite", choices=tuple(REVISIONS), required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--architecture", type=Path, required=True)
    parser.add_argument("--clang", type=Path, default=Path("/usr/local/bin/clang"))
    parser.add_argument("--clangxx", type=Path, default=Path("/usr/local/bin/clang++"))
    parser.add_argument("--llvm-extract", type=Path,
                        default=Path("/usr/local/bin/llvm-extract"))
    parser.add_argument("--mlir-translate", type=Path,
                        default=Path("/home/x/shiran/llvm-project/build/bin/mlir-translate"))
    parser.add_argument("--neura-opt", type=Path, required=True)
    parser.add_argument("--stage-timeout", type=int, default=90)
    args = parser.parse_args()
    result = import_suite(args.suite, args.source_root, args.output_dir,
                          args.architecture, args.clang, args.clangxx,
                          args.llvm_extract, args.mlir_translate,
                          args.neura_opt, args.stage_timeout)
    print(json.dumps({"manifest": str(args.output_dir / "import-manifest.json"),
                      "accepted_source_cases": result["accepted_source_cases"],
                      "distinct_mapper_input_dfg_count": result["distinct_mapper_input_dfg_count"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
